<?php

echo "Nome:" . $_POST['nome'];
echo "<br>";
echo "Idade:" . $_POST['idade'];
echo "<br>";
echo "Cidade Natal::" . $_POST['city'];

?>